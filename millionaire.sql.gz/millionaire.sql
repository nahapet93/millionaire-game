-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2019 at 11:39 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `millionaire`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

DROP TABLE IF EXISTS `answers`;
CREATE TABLE `answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `question_id` bigint(20) UNSIGNED NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_correct` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `question_id`, `content`, `is_correct`, `created_at`, `updated_at`) VALUES
(1, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry', 0, '2019-05-15 12:52:33', '2019-05-15 12:52:33'),
(2, 1, 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', 0, '2019-05-15 12:52:33', '2019-05-15 12:52:33'),
(3, 1, 'when an unknown printer took a galley of type and scrambled it to make a type specimen book', 1, '2019-05-15 12:52:34', '2019-05-15 12:52:34'),
(4, 1, 'It has survived not only five centuries, but also the leap into electronic typesetting', 0, '2019-05-15 12:52:34', '2019-05-15 12:52:34'),
(5, 2, 'It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages', 0, '2019-05-15 12:53:11', '2019-05-15 12:53:11'),
(6, 2, 'and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', 1, '2019-05-15 12:53:11', '2019-05-15 12:53:11'),
(7, 2, 'Contrary to popular belief, Lorem Ipsum is not simply random text', 0, '2019-05-15 12:53:11', '2019-05-15 12:53:11'),
(8, 2, 'It has roots in a piece of classical Latin literature from 45 BC', 0, '2019-05-15 12:53:11', '2019-05-15 12:53:11'),
(9, 3, 'Contrary to popular belief, Lorem Ipsum is not simply random text.', 0, '2019-05-15 12:54:21', '2019-05-15 12:54:21'),
(10, 3, 'It has roots in a piece of classical Latin literature from 45 BC', 1, '2019-05-15 12:54:21', '2019-05-15 12:54:21'),
(11, 3, 'making it over 2000 years old. Richard McClintock', 0, '2019-05-15 12:54:21', '2019-05-15 12:54:21'),
(12, 3, 'a Latin professor at Hampden-Sydney College in Virginia', 1, '2019-05-15 12:54:21', '2019-05-15 12:54:21'),
(13, 4, 'consectetur, from a Lorem Ipsum passage', 1, '2019-05-15 12:55:05', '2019-05-15 12:55:05'),
(14, 4, 'and going through the cites of the word in classical literature', 0, '2019-05-15 12:55:05', '2019-05-15 12:55:05'),
(15, 4, 'discovered the undoubtable source. Lorem Ipsum comes from sections', 1, '2019-05-15 12:55:05', '2019-05-15 12:55:05'),
(16, 4, '1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil)', 0, '2019-05-15 12:55:05', '2019-05-15 12:55:05'),
(17, 5, 'of ethics, very popular during the Renaissance. The first line of Lorem Ipsum', 1, '2019-05-15 12:55:56', '2019-05-15 12:55:56'),
(18, 5, '\"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.', 0, '2019-05-15 12:55:56', '2019-05-15 12:55:56'),
(19, 5, 'The standard chunk of Lorem Ipsum used since the 1500s', 0, '2019-05-15 12:55:56', '2019-05-15 12:55:56'),
(20, 5, 'is reproduced below for those interested.', 0, '2019-05-15 12:55:56', '2019-05-15 12:55:56'),
(21, 6, 'by Cicero are also reproduced in their exact original form, accompanied', 1, '2019-05-15 12:56:53', '2019-05-15 12:56:53'),
(22, 6, 'by English versions from the 1914 translation by H. Rackham.', 0, '2019-05-15 12:56:54', '2019-05-15 12:56:54'),
(23, 6, 'Contrary to popular belief, Lorem Ipsum is not simply random text', 0, '2019-05-15 12:56:54', '2019-05-15 12:56:54'),
(24, 6, 'It has roots in a piece of classical Latin literature from 45 BC', 1, '2019-05-15 12:56:54', '2019-05-15 12:56:54'),
(25, 7, 'It is a long established fact that a reader will be distracted by the readable content', 1, '2019-05-15 12:57:38', '2019-05-15 12:57:38'),
(26, 7, 'of a page when looking at its layout. The point of using Lorem Ipsum', 0, '2019-05-15 12:57:38', '2019-05-15 12:57:38'),
(27, 7, 'is that it has a more-or-less normal distribution of letters', 0, '2019-05-15 12:57:38', '2019-05-15 12:57:38'),
(28, 7, 'as opposed to using \'Content here, content here\', making it look like readable English', 1, '2019-05-15 12:57:38', '2019-05-15 12:57:38'),
(29, 8, 'as their default model text, and a search for \'lorem ipsum\'', 0, '2019-05-15 12:58:24', '2019-05-15 12:58:24'),
(30, 8, 'will uncover many web sites still in their infancy.', 0, '2019-05-15 12:58:24', '2019-05-15 12:58:24'),
(31, 8, 'Various versions have evolved over the years', 0, '2019-05-15 12:58:24', '2019-05-15 12:58:24'),
(32, 8, 'sometimes by accident, sometimes on purpose (injected humour and the like).', 1, '2019-05-15 12:58:24', '2019-05-15 12:58:24'),
(33, 9, 'There are many variations of passages of Lorem Ipsum available', 0, '2019-05-15 13:03:22', '2019-05-15 13:03:22'),
(34, 9, 'but the majority have suffered alteration in some form, by injected', 1, '2019-05-15 13:03:22', '2019-05-15 13:03:22'),
(35, 9, 'humour, or randomised words which don\'t look even slightly', 0, '2019-05-15 13:03:22', '2019-05-15 13:03:22'),
(36, 9, 'humour, or randomised words which don\'t look even slightly believable', 0, '2019-05-15 13:03:22', '2019-05-15 13:03:22'),
(37, 10, 'you need to be sure there isn\'t anything embarrassing hidden in the middle of text', 1, '2019-05-15 13:04:01', '2019-05-15 13:04:01'),
(38, 10, 'All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary', 1, '2019-05-15 13:04:01', '2019-05-15 13:04:01'),
(39, 10, 'making this the first true generator on the Internet.', 0, '2019-05-15 13:04:01', '2019-05-15 13:04:01'),
(40, 10, 'It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures', 0, '2019-05-15 13:04:01', '2019-05-15 13:04:01'),
(41, 11, 'The generated Lorem Ipsum is therefore always', 0, '2019-05-15 13:16:49', '2019-05-15 13:16:49'),
(42, 11, 'free from repetition, injected humour, or non-characteristic words etc.', 1, '2019-05-15 13:16:49', '2019-05-15 13:16:49'),
(43, 11, 'by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.', 0, '2019-05-15 13:16:49', '2019-05-15 13:16:49'),
(44, 11, 'and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The', 0, '2019-05-15 13:16:49', '2019-05-15 13:16:49'),
(45, 12, 'If you use this site regularly and would like to help keep the site on the Internet', 0, '2019-05-15 13:17:26', '2019-05-15 13:17:26'),
(46, 12, 'please consider donating a small sum to help pay for the hosting and bandwidth bill.', 0, '2019-05-15 13:17:26', '2019-05-15 13:17:26'),
(47, 12, 'There is no minimum donation, any sum is appreciated - click here', 1, '2019-05-15 13:17:27', '2019-05-15 13:17:27'),
(48, 12, 'to donate using PayPal. Thank you for your support.', 0, '2019-05-15 13:17:27', '2019-05-15 13:17:27'),
(49, 13, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do', 1, '2019-05-15 13:18:08', '2019-05-15 13:18:08'),
(50, 13, 'eiusmod tempor incididunt ut labore et dolore magna aliqua.', 0, '2019-05-15 13:18:08', '2019-05-15 13:18:08'),
(51, 13, 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat', 0, '2019-05-15 13:18:08', '2019-05-15 13:18:08'),
(52, 13, 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 0, '2019-05-15 13:18:08', '2019-05-15 13:18:08'),
(53, 14, 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium', 0, '2019-05-15 13:18:48', '2019-05-15 13:18:48'),
(54, 14, 'doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis', 0, '2019-05-15 13:18:49', '2019-05-15 13:18:49'),
(55, 14, 'et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem', 1, '2019-05-15 13:18:49', '2019-05-15 13:18:49'),
(56, 14, 'quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores', 0, '2019-05-15 13:18:49', '2019-05-15 13:18:49'),
(57, 15, 'eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur', 0, '2019-05-15 13:19:30', '2019-05-15 13:19:30'),
(58, 15, 'adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam', 0, '2019-05-15 13:19:30', '2019-05-15 13:19:30'),
(59, 15, 'quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi', 0, '2019-05-15 13:19:30', '2019-05-15 13:19:30'),
(60, 15, 'ut aliquid ex ea commodi consequatur? Quis autem vel eum iure', 1, '2019-05-15 13:19:31', '2019-05-15 13:19:31'),
(61, 16, 'But I must explain to you how all this mistaken idea of denouncing pleasure', 0, '2019-05-15 13:20:28', '2019-05-15 13:20:28'),
(62, 16, 'account of the system, and expound the actual teachings of the great explorer', 1, '2019-05-15 13:20:28', '2019-05-15 13:20:28'),
(63, 16, 'of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure', 1, '2019-05-15 13:20:28', '2019-05-15 13:20:28'),
(64, 16, 'but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful', 0, '2019-05-15 13:20:28', '2019-05-15 13:20:28'),
(65, 17, 'Nor again is there anyone who loves or pursues or desires to obtain pain of', 1, '2019-05-15 13:21:30', '2019-05-15 13:21:30'),
(66, 17, 'itself, because it is pain, but because occasionally circumstances', 0, '2019-05-15 13:21:30', '2019-05-15 13:21:30'),
(67, 17, 'occur in which toil and pain can procure him some great pleasure. To take a trivial example', 1, '2019-05-15 13:21:30', '2019-05-15 13:21:30'),
(68, 17, 'which of us ever undertakes laborious physical exercise, except to obtain some advantage from it?', 0, '2019-05-15 13:21:30', '2019-05-15 13:21:30'),
(69, 18, 'that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?\"', 1, '2019-05-15 13:22:27', '2019-05-15 13:22:27'),
(70, 18, 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis', 0, '2019-05-15 13:22:27', '2019-05-15 13:22:27'),
(71, 18, 'praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi', 0, '2019-05-15 13:22:27', '2019-05-15 13:22:27'),
(72, 18, 'sint occaecati cupiditate non provident, similique sunt in culpa', 1, '2019-05-15 13:22:27', '2019-05-15 13:22:27');

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

DROP TABLE IF EXISTS `games`;
CREATE TABLE `games` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `is_finished` tinyint(4) NOT NULL DEFAULT '0',
  `score` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `games_questions`
--

DROP TABLE IF EXISTS `games_questions`;
CREATE TABLE `games_questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `game_id` bigint(20) UNSIGNED NOT NULL,
  `question_id` bigint(20) UNSIGNED NOT NULL,
  `is_answered` tinyint(4) NOT NULL DEFAULT '0',
  `is_correctly_answered` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_05_14_194735_add_role_to_users_table', 2),
(4, '2019_05_14_201043_create_questions_table', 3),
(5, '2019_05_14_201522_create_answers_table', 4),
(6, '2019_05_14_202640_create_games_table', 4),
(7, '2019_05_14_204619_create_games_questions_table', 4),
(8, '2019_05_16_200322_add_is_answered_to_games_questions_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE `questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `points` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `content`, `points`, `created_at`, `updated_at`) VALUES
(1, 'What is Lorem Ipsum?', 5, '2019-05-15 12:52:33', '2019-05-15 12:52:33'),
(2, 'remaining essentially unchanged', 5, '2019-05-15 12:53:11', '2019-05-15 12:53:11'),
(3, 'Where does it come from?', 5, '2019-05-15 12:54:21', '2019-05-15 12:54:21'),
(4, 'looked up one of the more obscure Latin words', 5, '2019-05-15 12:55:05', '2019-05-15 12:55:05'),
(5, 'by Cicero, written in 45 BC. This book is a treatise on the theory', 7, '2019-05-15 12:55:56', '2019-05-15 12:55:56'),
(6, 'Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\"', 7, '2019-05-15 12:56:53', '2019-05-15 12:56:53'),
(7, 'Why do we use it?', 7, '2019-05-15 12:57:38', '2019-05-15 12:57:38'),
(8, 'Many desktop publishing packages and web page editors now use Lorem Ipsum', 7, '2019-05-15 12:58:24', '2019-05-15 12:58:24'),
(9, 'Where can I get some?', 10, '2019-05-15 13:03:22', '2019-05-15 13:03:22'),
(10, 'If you are going to use a passage of Lorem Ipsum', 10, '2019-05-15 13:04:01', '2019-05-15 13:04:01'),
(11, 'to generate Lorem Ipsum which looks reasonable.', 10, '2019-05-15 13:16:49', '2019-05-15 13:16:49'),
(12, 'Can you help translate this site into a foreign language ? Please email us with details if you can help.', 10, '2019-05-15 13:17:26', '2019-05-15 13:17:26'),
(13, 'The standard Lorem Ipsum passage, used since the 1500s', 14, '2019-05-15 13:18:08', '2019-05-15 13:18:08'),
(14, 'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\"', 14, '2019-05-15 13:18:48', '2019-05-15 13:18:48'),
(15, 'Section 1.10.32 of \"de Finibus Bonorum et Malorum\", written by Cicero in 45 BC', 14, '2019-05-15 13:19:30', '2019-05-15 13:19:30'),
(16, 'reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?\"', 14, '2019-05-15 13:20:28', '2019-05-15 13:20:28'),
(17, '1914 translation by H. Rackham', 20, '2019-05-15 13:21:30', '2019-05-17 16:49:56'),
(18, 'But who has any right to find fault with a man who chooses to enjoy a pleasure', 20, '2019-05-15 13:22:27', '2019-05-15 13:22:27');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `role`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@gmail.com', NULL, '$2y$10$l5VR6JPLtT/YrYkrrrvK1eoqalxErq9XXjZnhKArW2l3gwZQrIhbC', 'pHiYBw84iLK93cCtO4kwceaMVM2fCBVYMEIlXtTktciJQVwxDQFhMLDkj2OJ', 10, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `answers_question_id_foreign` (`question_id`);

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`id`),
  ADD KEY `games_user_id_foreign` (`user_id`);

--
-- Indexes for table `games_questions`
--
ALTER TABLE `games_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `games_questions_game_id_foreign` (`game_id`),
  ADD KEY `games_questions_question_id_foreign` (`question_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `games`
--
ALTER TABLE `games`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `games_questions`
--
ALTER TABLE `games_questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answers`
--
ALTER TABLE `answers`
  ADD CONSTRAINT `answers_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `games`
--
ALTER TABLE `games`
  ADD CONSTRAINT `games_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `games_questions`
--
ALTER TABLE `games_questions`
  ADD CONSTRAINT `games_questions_game_id_foreign` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `games_questions_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
